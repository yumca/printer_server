/* printcrc16 extension for PHP */

#ifndef PHP_PRINTCRC16_H
# define PHP_PRINTCRC16_H

extern zend_module_entry printcrc16_module_entry;
# define phpext_printcrc16_ptr &printcrc16_module_entry

# define PHP_PRINTCRC16_VERSION "0.1.0"

# if defined(ZTS) && defined(COMPILE_DL_PRINTCRC16)
ZEND_TSRMLS_CACHE_EXTERN()
# endif

#endif	/* PHP_PRINTCRC16_H */

