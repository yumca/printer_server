/* printcrc16 extension for PHP */

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "php.h"
#include "ext/standard/info.h"
#include "php_printcrc16.h"

/* For compatibility with older PHP versions */
#ifndef ZEND_PARSE_PARAMETERS_NONE
#define ZEND_PARSE_PARAMETERS_NONE() \
	ZEND_PARSE_PARAMETERS_START(0, 0) \
	ZEND_PARSE_PARAMETERS_END()
#endif

/* {{{ void printcrc16_test1()
 */
PHP_FUNCTION(confirm_print_crc16_compiled)
{
	char *arg = NULL;
	size_t arg_len, len;
	zend_string *strg;

	if (zend_parse_parameters(ZEND_NUM_ARGS(), "s", &arg, &arg_len) == FAILURE) {
		return;
	}

	strg = strpprintf(0, "Congratulations! You have successfully modified ext/%.78s/config.m4. Module %.78s is now compiled into PHP.", "printcrc16", arg);

	RETURN_STR(strg);
}
/* }}} */

/* {{{ string printcrc16_test2( [ string $var ] )
 */
PHP_FUNCTION(print_crc16)
{
	zend_string *str;
    size_t len;

	if (zend_parse_parameters(ZEND_NUM_ARGS(), "s", &str, &len) == FAILURE) {
		RETURN_NULL();
	}
    unsigned char * dataPtr = ( unsigned char * ) str;
    unsigned int index = 0;
    unsigned short crc = 0;
    while(len--)
    {
        crc = ( unsigned char ) ( crc >> 8) | ( crc << 8);
        crc ^= dataPtr[index++];
        crc ^= ( unsigned char ) ( crc & 0xff ) >> 4;
        crc ^= ( crc << 8) << 4;
        crc ^= ( ( crc & 0xff ) << 4) << 1;
    }
	RETURN_LONG(crc);
}
/* }}}*/

/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(printcrc16)
{
#if defined(ZTS) && defined(COMPILE_DL_PRINTCRC16)
	ZEND_TSRMLS_CACHE_UPDATE();
#endif

	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(printcrc16)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "printcrc16 support", "enabled");
	php_info_print_table_end();
}
/* }}} */

/* {{{ arginfo
 */
ZEND_BEGIN_ARG_INFO(arginfo_printcrc16_test1, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO(arginfo_printcrc16_test2, 0)
	ZEND_ARG_INFO(0, str)
ZEND_END_ARG_INFO()
/* }}} */

/* {{{ printcrc16_functions[]
 */
static const zend_function_entry printcrc16_functions[] = {
	PHP_FE(confirm_print_crc16_compiled,	NULL)
	PHP_FE(print_crc16,		NULL)
	/* PHP_FE(printcrc16,		arginfo_printcrc16_test1) */
	/* PHP_FE(printcrc16,		arginfo_printcrc16_test2) */
	PHP_FE_END
};
/* }}} */

/* {{{ printcrc16_module_entry
 */
zend_module_entry printcrc16_module_entry = {
	STANDARD_MODULE_HEADER,
	"printcrc16",					/* Extension name */
	printcrc16_functions,			/* zend_function_entry */
	NULL,							/* PHP_MINIT - Module initialization */
	NULL,							/* PHP_MSHUTDOWN - Module shutdown */
	PHP_RINIT(printcrc16),			/* PHP_RINIT - Request initialization */
	NULL,							/* PHP_RSHUTDOWN - Request shutdown */
	PHP_MINFO(printcrc16),			/* PHP_MINFO - Module info */
	PHP_PRINTCRC16_VERSION,		/* Version */
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_PRINTCRC16
# ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
# endif
ZEND_GET_MODULE(printcrc16)
#endif

